/** Automatically generated file. DO NOT MODIFY */
package com.sci.smsonce;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}