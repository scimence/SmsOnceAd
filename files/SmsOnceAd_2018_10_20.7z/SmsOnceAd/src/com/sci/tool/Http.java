﻿
package com.sci.tool;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import com.sci.tool.ThreadTool.ThreadPram;


public class Http
{
	private static boolean isGetData = false;
	private static String _GetData = "";
	/** 获取指定网页数据，可在任意位置调用，包括主线程中 */
	public static String Get(final String url)
	{
		_GetData = "";
		isGetData = false;
		ThreadTool.RunInCachedThread(new ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在其它线程执行逻辑
				_GetData = Get_Process(url);
				isGetData = true;
			}
		});
		
		int count = 0;
		while(!isGetData)
		{
			if(count++ > 70) break;
			try
			{
				Thread.sleep(100);
			}
			catch (InterruptedException e)
			{
			}
		}
		return _GetData;
	}
	
	// url = "http://www.baidu.com"
	private static String Get_Process(String url)
	{
		try
		{
			StringBuilder tmp = new StringBuilder();
			
			URL URL_ = new URL(url);
			InputStream in = URL_.openStream();
			InputStreamReader isr = new InputStreamReader(in);
			BufferedReader bufr = new BufferedReader(isr);
			
			String str;
			while ((str = bufr.readLine()) != null)
			{
				// System.out.println(str);
				tmp.append(str + "\r\n");
			}
			bufr.close();
			isr.close();
			in.close();
			
			return tmp.toString();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return "";
		}
	}
}
