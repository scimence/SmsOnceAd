package com.sci.tool;

import android.content.Context;

/** 在本地或远程记录数据 */
public class AppDB 
{
	public static boolean isLocalDB = true;	// 标识是否为本地数据记录模式
	Context context;
	
	public void AppDB(Context context)
	{
		context = this.context;
	}
	
	
}
