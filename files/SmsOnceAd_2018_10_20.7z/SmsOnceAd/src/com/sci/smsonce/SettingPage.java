
package com.sci.smsonce;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ScrollView;

import com.sci.tool.ActivityComponent;
import com.sci.tool.Http;
import com.sci.tool.Preference;


/** 设置页面 */
public class SettingPage extends ActivityComponent
{
	Preference	set		= new Preference(this, "set_data_server");	// 获取data数据集合
	Preference	setSms	= new Preference(this, "set_data_sms");	// 获取data数据集合
																	
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("setting_page");
		
		loadSetting();	// 载入本地配置信息
	}
	
	public void finish()
	{
		super.finish();
		
		Intent intent = new Intent(this, MainActivity.class);
		this.startActivity(intent);
	}
	
	@Override
	public void Click(String viewId)
	{
		//		ShowTip(viewId);
		
		// 上传已发送号码
		if (viewId.equals("button_upload"))
		{
			UploadAlreadySend();
		}
		
		// 未发送号码去重
		else if (viewId.equals("button_check_sended"))
		{
			ClearServerAlreadySend();
		}
		
		// 保存
		else if (viewId.equals("button_save"))
		{
			String serverAddress = EditText("editText_serverAddress").getText().toString().trim(); 	// 获取服务器地址信息
			String tableName = EditText("editText_tableName").getText().toString().trim(); 			// 获取数据表名称
			
			set.put("serverAddress", serverAddress);
			set.put("tableName", tableName);
			
			ShowTip("配置以保存" + tableName);
			ShowTip("服务器地址：" + serverAddress);
			ShowTip("数据表名称：" + tableName);
			ShowTip("#\r\n");
		}
		// 清空
		else if (viewId.equals("button_clear"))
		{
			new AlertDialog.Builder(this).setTitle("确定清空所有配置信息？").setPositiveButton("确定", new DialogInterface.OnClickListener()
			{
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					set.clear();
					ShowTip("配置信息已清空\r\n");
				}
			}).setNegativeButton("取消", null).show();
		}
	}
	
	/** 载入配置信息 */
	private void loadSetting()
	{
		String serverAddress = set.get("serverAddress");
		String tableName = set.get("tableName");
		
		EditText("editText_serverAddress").setText(serverAddress);
		EditText("editText_tableName").setText(tableName);
	}
	
	/** 上传已发送过的号码信息 */
	private void UploadAlreadySend()
	{
		// 获取服务器地址、数据表名称
		String serverAddress = EditText("editText_serverAddress").getText().toString().trim();
		String tableName = EditText("editText_tableName").getText().toString().trim();
		
		int count = 0;
		int countAll = setSms.ValueNum("true");
		
		// 获取所有号码信息
		List<String> keys = setSms.Keys();
		for (String key : keys)
		{
			String value = setSms.get(key);
			if (value.equals("true"))
			{
				// 添加信息 至服务器
				String url = serverAddress + "?TAB=" + tableName + "&KEY=" + key + "&VALUE=true";
				String data = Http.Get(url);
//				String data = HttpTool.request(url, null, "get");
				// 成功： success
				// 失败：
				
				if (data.trim().equals("success"))
				{	// 若发送成功，则从本地记录信息中移除
					setSms.remove(key);
					ShowTip("上传：" + key + "  " + (++count) + "/" + countAll);
				}
				else
				{
					ShowTip("上传失败！" + url);
					ShowTip("-> " + data);
					break;
				}
				if(count == countAll) ShowTip("上传完成！\r\n");
			}
		}
	}
	
	/** 清除服务器端记录已发送过的号码信息 */
	private void ClearServerAlreadySend()
	{
		// 获取服务器地址、数据表名称
		String serverAddress = EditText("editText_serverAddress").getText().toString().trim();
		String tableName = EditText("editText_tableName").getText().toString().trim();
		
		int count = 0;
		int countAll = setSms.ValueNum("false");
		boolean haveAlreadySend = false;
		
		// 获取所有号码信息
		List<String> keys = setSms.Keys();
		for (String key : keys)
		{
			String value = setSms.get(key);
			if (value.equals("false"))
			{
				// 从服务器 查询信息
				String url = serverAddress + "?TAB=" + tableName + "&KEY=" + key;
				String data = Http.Get(url).trim();
				// 成功： {"日期":"2018-10-20_18:25:53_432528","标签":"TAG4","信息":"添加log信息"} 
				// 失败：success
				
				if (data.contains("{") && data.contains("}") && data.contains("\"" + key + "\""))
				{	// 若
					setSms.remove(key);
					ShowTip("去重：" + key + "  " + (++count) + "/" + countAll);
					haveAlreadySend = true;
				}
			}
		}
		if(haveAlreadySend) ShowTip("去重完成！\r\n");
	}
	
	//	接口使用说明：
	//
	
	//	添加信息：http://60.205.185.168:8001/Pages/WebInfo.aspx?TAB=测试表&KEY=TAG4&VALUE=添加log信息
	//		success
	//		
	//	修改信息：http://60.205.185.168:8001/Pages/WebInfo.aspx?TAB=测试表&KEY=TAG4&VALUE_M=修改log信息
	//
	//	删除信息：http://60.205.185.168:8001/Pages/WebInfo.aspx?TAB=测试表&KEY_D=TAG4
	//
	//	查询所有信息：http://60.205.185.168:8001/Pages/WebInfo.aspx?TAB=测试表
	//
	//	查询指定信息：http://60.205.185.168:8001/Pages/WebInfo.aspx?TAB=测试表&KEY=TAG55
	//	{"日期":"2018-10-20_18:25:53_432528","标签":"TAG4","信息":"添加log信息"} success
	
	
	// --------------------
	
	/** 输出信息至文本框 */
	@SuppressLint("SimpleDateFormat")
	private void ShowTip(String msg)
	{
		if (msg.startsWith("#"))
		{
			msg = msg.substring(1);
		}
		else
		{
			SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss ");
			String time = format.format(new Date());
			
			msg = time + msg;
		}
		
		EditText("edit_tips").append("\r\n" + msg);
		
		ScrollView("scrollView_tips").fullScroll(ScrollView.FOCUS_DOWN);	//ScrollView滚动至底部 
	}
	
}
