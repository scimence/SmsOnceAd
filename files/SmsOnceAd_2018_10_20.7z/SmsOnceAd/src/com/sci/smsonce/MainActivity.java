
package com.sci.smsonce;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.ScrollView;
import android.widget.Toast;

import com.sci.tool.ActivityComponent;
import com.sci.tool.Preference;


public class MainActivity extends ActivityComponent
{
	
	Preference	set	= new Preference(this, "set_data_sms"); // 获取data数据集合
															
	@Override
	public void Init(Bundle savedInstanceState)
	{
		
		this.setContentView("activity_main"); // 设置页面布局
		this.setRequestedOrientation(1); // 设置为竖屏显示
		
		loadDatas();
	}
	
	@Override
	public void Click(String viewId)
	{
		// ShowTip(viewId);
		
		// 记录添加手机号信息
		if (viewId.equals("button_addphone"))
		{
			String content = EditText("editText_msg").getText().toString().trim(); // 获取内容信息
			AddContent(content);
			
			String phoneId = EditText("editText_phone").getText().toString().trim();// 获取手机号信息
			if (phoneId.length() >= 11)
			{
				EditText("editText_phone").setText(""); // 清空输入框
				AddPhoneNumber(phoneId);
			}
			else
			{	
				ShowTip("输入的号码位数不足，请确认！\r\n");
			}
			
		}
		
		// 设置
		else if (viewId.equals("button_setting"))
		{
			this.finish();
			
			Intent intent = new Intent(this, SettingPage.class);
			this.startActivity(intent);
		}
		
		// 清空
		else if (viewId.equals("button_clear"))
		{
			new AlertDialog.Builder(this).setTitle("确定清空所有配置信息？").setPositiveButton("确定", new DialogInterface.OnClickListener()
			{
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					set.clear();
					ShowTip("配置信息已清空\r\n");
				}
			}).setNegativeButton("取消", null).show();
		}
		
		// 发送
		else if (viewId.equals("button_send"))
		{
			SendSMS();
		}
	}
	
	/** 发送所有短信息 */
	private void SendSMS()
	{
		// 获取短信内容信息
		String msg = EditText("editText_msg").getText().toString().trim();
		AddContent(msg);
		
		if (msg.trim().equals(""))
		{
			ShowTip("请添加待发送信息！");
			return;
		}
		
		int count = 0;
		int countAll = set.ValueNum("false");
		boolean haveSend = false;
		
		List<String> keys = set.Keys();
		if (keys.contains("content")) keys.remove("content");
		for (String key : keys)
		{
			String value = set.get(key);
			if (value.equals("false"))
			{
				ShowTip("发送：" + key + "  " + (++count) + "/" + countAll);
				boolean result = SendSMS(key, msg);		// 调用发送短信
				if (result)
				{
					set.put(key, "true");	// 记录号码为已发送
					haveSend = true;
				}
				else
				{
					ShowTip("发送失败！");
					break;
				}
			}
		}
		if(haveSend) ShowTip("发送完成！\r\n");
	}
	
	/** 发送短信 */
	private boolean SendSMS(String tel, String msg)
	{
		try
		{
			SmsManager smsManager = SmsManager.getDefault();
	        smsManager.sendTextMessage(tel,null,msg,null,null);
	        
			//			Intent intent = new Intent();
			//			intent.setAction(Intent.ACTION_SENDTO); //设置为发送
			//			intent.setData(Uri.parse("smsto:" + tel));//设置号码
			//			intent.putExtra("sms_body", msg);		//设置内容
			//			startActivity(intent);
			return true;
		}
		catch (Exception ex)
		{
			return false;
		}
	}
	
	/** 添加内容信息 */
	private void AddContent(String content)
	{
		if (!content.equals(""))
		{
			String value = set.get("content"); // 获取保存的content信息
			if (!content.equals(value))
			{
				set.put("content", content); // 记录内容信息
				
				ShowTip("添加内容信息：");
				ShowTip(content);
				ShowTip("#\r\n");
			}
		}
	}
	
	/** 添加手机号 */
	private void AddPhoneNumber(String number)
	{
		if (number.trim().equals("")) return;
		
		ShowTip("添加手机号：" + number);
		if (!set.Keys().contains(number))
		{
			set.put(number, "false"); // 记录手机号
			ShowTip("号码已添加！");
		}
		else
		{
			ShowTip("此号码已存在！");
		}
		ShowTip("#\r\n");
	}
	
	/** 载入已保存的数据信息 */
	private void loadDatas()
	{
		String content = set.get("content");
		EditText("editText_msg").setText(content);
		
		ShowTip("可发送信息的手机号数目：" + set.ValueNum("false") + "\r\n");
	}
	
	//	// 统计待发送的号码总数
	//	private int NotSend()
	//	{
	//		List<String> keys = set.Keys();
	//		int count = 0;
	//		for (String key : keys)
	//		{
	//			String value = set.get(key);
	//			if (value.equals("false")) count++;
	//		}
	//		return count;
	//	}
	
	// --------------------
	
	/** 输出信息至文本框 */
	@SuppressLint("SimpleDateFormat")
	private void ShowTip(String msg)
	{
		if (msg.startsWith("#"))
		{
			msg = msg.substring(1);
		}
		else
		{
			SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss ");
			String time = format.format(new Date());
			
			msg = time + msg;
		}
		
		EditText("edit_tips").append("\r\n" + msg);
		
		ScrollView("scrollView_tips").fullScroll(ScrollView.FOCUS_DOWN);	//ScrollView滚动至底部 
	}
	
	/** 显示提示信息 */
	public void ShowText(String msg)
	{
		Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
	}
	
	//
	// @Override
	// public boolean onCreateOptionsMenu(Menu menu)
	// {
	// // Inflate the menu; this adds items to the action bar if it is present.
	// getMenuInflater().inflate(R.menu.main, menu);
	// return true;
	// }
	//
	
}
